/*
* COP3402 - Spring 2018
* System Software Assignment 3
* Submitted by: Suraj Singireddy (su365398), Gavin Knopp (ga803888)
*/

Compile: gcc main.c pcg.c lexical.c pm0vm.c